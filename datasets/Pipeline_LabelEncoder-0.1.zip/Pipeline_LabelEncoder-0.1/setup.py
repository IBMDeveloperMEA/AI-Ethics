from setuptools import setup

setup(name='Pipeline_LabelEncoder',
      version=0.1,
      description='Modified Scikit-Learn Label Encoder to fit in pipeline ',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=[
            'Pipeline_LabelEncoder'
      ],
      zip_safe=False)
